---
title: Nginx常用代理场景及常用配置
tags: [nginx,proxy_pass,minio,client_max_body_size,upstream,SPA,rewrite,动态代理,大文件上传,反向代理,负载均衡,单页应用]
---

#### 0x00: 常见代理
  - 代理允许跨域
  ``` nginx
    location /api_cros {
      proxy_set_header 'Access-Control-Allow-Origin' '*';
      proxy_pass http://127.0.0.1:8080/;
    }
  ```
  - 代理minio
  ``` nginx
    location /api_minio {
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $scheme;
      proxy_set_header Host 127.0.0.1:9000;
      rewrite ^/api_minio/(.*)$ /$1 break;
      proxy_pass http://127.0.0.1:9000/;
    }
  ```
  - 代理百度地图Web接口
  ``` nginx
    location ^~/api_baidu_map {
      rewrite  ^/api_baidu_map/(.*)$ /$1 break;
      proxy_pass http://api.map.baidu.com;
    }
  ```
  - 动态代理IP类接口
  ``` nginx
    location /{
      proxy_set_header Host $http_host;
      proxy_redirect off;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Scheme $scheme;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      if ( $args ~ ^url\=(.*) ) {
        set $url $1;
        proxy_pass $url;
      }
    }
  ```
    调用：http://127.0.0.1/api?url=http://127.0.0.1:8080/api/getList?pageSize=10&pageNum=1

  - 代理超图3D
  ``` nginx
    location / {    
      proxy_hide_header X-Frame-Options;
      add_header X-Frame-Options "";    
      proxy_pass http://127.0.0.1:8090/;
    }
  ```

  - 代理Auth2
  ``` nginx
		location /api {
		 if ($request_method = 'OPTIONS') {
          add_header Access-Control-Allow-Origin $http_origin;
          add_header Access-Control-Allow-Headers $http_access_control_request_headers;
          return 200;
        } 
        proxy_pass http://127.0.0.1:8082/;
    }
  ```

  - 代理MySQL
  ``` nginx
		stream {
      server {
        listen 13306;
        proxy_pass 114.114.114.114:3306;
      }
    }
  ```

  - 代理科达地图
  ``` nginx
		location / {
			proxy_set_header Accept-Encoding "" ;
			sub_filter_once off;
			sub_filter_types *;
			sub_filter 'KDMAP_SERVER_ADDRESS' 'http://127.0.0.1:44444';
			proxy_pass KDMAP_SERVER_ADDRESS;
		}
  ```

#### 0x01: 常用配置
  - 大文件上传
  ``` nginx
    client_max_body_size 800m;
  ```
  - gzip压缩
  ``` nginx
    gzip on;
    gzip_min_length 1000;
    gzip_buffers 4 32k;
    gzip_proxied any;
    gzip_types text/plain text/css text/javascript image/jpeg image/gif image/png application/json;
    gzip_vary on;
  ```
  - 单页应用(SPA)
  ``` nginx
    location / {
      index index.html;
      #单页路由刷新404
      try_files $uri $uri/ /index.html;
    }
  ```
  - 多服务实例(负载均衡)
  ``` nginx
    upstream API {
      ip_hash;
      server 127.0.0.1:8080 weight=7;
      server 127.0.0.1:8081;
      server 127.0.0.1:8082;
    }
  ```
  - 字符串替换
  ``` nginx
      sub_filter_once off;
      sub_filter_types *;
      sub_filter 'baidu.com' 'test.baidu.com';
  ```
  - rewrite
  ``` nginx
        location / {
          rewrite /order(.*)$ /order.php$1 last;
      };
  ```

  - SSL
  ``` nginx
    server {
      listen 443 ssl;
      server_name ssl.siping.one;
      access_log logs/ssl.siping.one.access.log;
      error_log logs/ssl.siping.one.error.log;
      root /frontend/mobile/next/dist;
      ssl_certificate /usr/local/nginx/cert/ssl.siping.one.crt;
      ssl_certificate_key /usr/local/nginx/cert/ssl.siping.one.key;
      ssl_session_timeout 5m;
      ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
      ssl_ciphers AESGCM:ALL:!DH:!EXPORT:!RC4:+HIGH:!MEDIUM:!LOW:!aNULL:!eNULL;
      ssl_prefer_server_ciphers on;
      location / {
        index index.html index.htm;
        try_files $uri $uri/ /index.html;
      }
    };
  ```
  - 重定向
  ``` nginx
    server {
      listen 80;
      server_name ssl.siping.one mobile.siping.one;
      rewrite ^/(.*) https://ssl.siping.one/$1 permanent;
    }
  ```
  - 文件包含
  ``` nginx
  http {
    include conf.d/*.conf;
  } 
  ```